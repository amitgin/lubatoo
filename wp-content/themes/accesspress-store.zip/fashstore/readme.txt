License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
FashStore WordPress Theme, Copyright 2015 AccessPress Themes
FashStore Store is distributed under the terms of the GNU GPL v3


Install Steps:
--------------

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

Image
-------------
License: CC0 Public Domain

https://pixabay.com/en/dress-long-woman-clothing-night-739665/
https://pixabay.com/en/outdoor-jeans-woman-young-fashion-1097951/
https://pixabay.com/en/handbag-fashion-pink-woman-female-1107716/
https://pixabay.com/en/attractive-beautiful-brunette-cute-15765/
https://pixabay.com/en/attractive-beautiful-body-smiling-19121/
https://pixabay.com/en/talk-communication-conversation-1034161/
https://pixabay.com/en/portrait-photography-girls-woman-828403/

== Changelog ==

Version 1.0.8
  * Fixed product variation dropdown

Version 1.0.7
 * Fixed add to cart button for various type of product
 * Fixed some bugs in responsive
 
Version 1.0.6
 * Fixed archive page list layout
 * Fixed design on menu section
 * Added more tags and changed theme description

Version 1.0.5
 * Fixed transaltion issue
 * Update fashstore.pot file
 
Version 1.0.4
 * Fixed transaltion issue
 
Version 1.0.3
 * Fixed issue and changed youtube bg image

Version 1.0.2
 * Fixed all issue listed bye reviewr
 * Changed screenshot
 
Version 1.0.1
 * Fixed all issue listed by reviwer
 * Fixed layout of Category banner
 
Version 1.0.0
 * Submit theme on wordpress.org for review